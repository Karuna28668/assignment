#include <iostream>
using namespace std;
class employee
{
    public:
    int salary,hour;
    
    void getinfo(int sal, int hr)
    {
        salary = sal;
        hour = hr;
    }
    
    void addsalary()
    {
        if(salary<500)
        {
            salary = 10 + salary;
        }
    }
    
    void addwork()
    {
        if(hour>6)
        {
            salary = salary + 5;
        }
    }
    void display()
    {
        cout<<"\nSalary = "<< salary<<endl<<"\nWork Hours = "<< hour <<endl;
    }

};

int main()
{
    int s,h;
    cout << "enter salary: ";
    cin >> s;
    cout << "enter hours: ";
    cin >> h;
    
    employee e1;
    e1.getinfo(s,h);
    
    if(s<500)
    {
        e1.addsalary();
    }
    
    if(h>6)
    {
        e1.addwork();
    }
    e1.display();
    return 0;
}
